"""Levenshtein distance and fuzzy matching utilities."""

from __future__ import annotations


def levenshtein_distance(s1: str, s2: str) -> int:
    """Compute the Levenshtein edit distance between two strings."""
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)

    if len(s2) == 0:
        return len(s1)

    previous_row = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row

    return previous_row[-1]


def suggest_alternatives(
    name: str, candidates: list[str], max_distance: int = 3, max_results: int = 5
) -> list[tuple[str, int]]:
    """Find candidates within max_distance, sorted by distance."""
    matches: list[tuple[str, int]] = []
    for candidate in candidates:
        dist = levenshtein_distance(name, candidate)
        if dist <= max_distance:
            matches.append((candidate, dist))
    matches.sort(key=lambda x: x[1])
    return matches[:max_results]
